//
//  main.m
//  HelloWorld
//
//  Created by Marcin Czenko on 7/19/11.
//  Copyright 2011 Everyday Productive. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HelloWorldAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HelloWorldAppDelegate class]));
    }
}
