//
//  UnitTests.m
//  UnitTests
//
//  Created by Marcin Czenko on 7/22/11.
//  Copyright 2011 Everyday Productive. All rights reserved.
//

#import "UnitTests.h"

@implementation UnitTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in UnitTests");
}

@end
