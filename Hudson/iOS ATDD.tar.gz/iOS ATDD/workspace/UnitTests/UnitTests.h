//
//  UnitTests.h
//  UnitTests
//
//  Created by Marcin Czenko on 7/22/11.
//  Copyright 2011 Everyday Productive. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface UnitTests : SenTestCase

@end
