task :version do
  require 'pp'
  pp version_hash
  pp version_string
end