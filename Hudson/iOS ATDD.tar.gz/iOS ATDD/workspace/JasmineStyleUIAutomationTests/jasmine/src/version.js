jasmine.version_= {
  "major": 1,
  "minor": 1,
  "build": 0,
  "revision": 1310556152,
  "release_candidate": 3
};
