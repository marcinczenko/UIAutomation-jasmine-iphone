module Jasmine
  module Core
    VERSION = "1.1.0.rc3"
  end
end

