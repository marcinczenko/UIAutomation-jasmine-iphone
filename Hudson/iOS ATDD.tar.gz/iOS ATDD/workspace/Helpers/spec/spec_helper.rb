$FIXTURES_PATH = String.new File.expand_path('../../features/fixtures',__FILE__)
$BIN_PATH = String.new File.expand_path('../../bin',__FILE__)

require 'Helpers'
require 'Runners'
